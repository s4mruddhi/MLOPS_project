"""
Apache Airflow DAG for RAGOps Enterprise Knowledge Assistant Pipeline Automation.
DAG ID: ragops_enterprise_pipeline
"""

from datetime import datetime, timedelta
import os
import sys
import json

# Add project root to sys.path for Airflow runtime
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

try:
    from airflow import DAG
    from airflow.operators.python import PythonOperator
    AIRFLOW_AVAILABLE = True
except ImportError:
    AIRFLOW_AVAILABLE = False


def task_ingest_documents():
    from src.data.doc_validation import DocumentValidator
    raw_dir = os.path.join(PROJECT_ROOT, "data", "raw")
    validator = DocumentValidator()
    valid_docs, rejected_docs, report = validator.validate_directory(raw_dir)
    print(f"Airflow Task [ingest_documents] completed. Found {report['total_files_scanned']} raw document files.")
    return report['total_files_scanned']


def task_validate_documents():
    from src.data.doc_validation import DocumentValidator
    raw_dir = os.path.join(PROJECT_ROOT, "data", "raw")
    report_path = os.path.join(PROJECT_ROOT, "data", "processed", "validation_report.json")
    validator = DocumentValidator()
    valid_docs, rejected_docs, report = validator.validate_directory(raw_dir, output_report_path=report_path)
    
    if len(rejected_docs) > 0:
        raise ValueError(f"Airflow Task [validate_documents] FAILED: {len(rejected_docs)} invalid documents rejected.")
    print(f"Airflow Task [validate_documents] PASSED. {len(valid_docs)} documents validated successfully.")


def task_extract_text():
    raw_dir = os.path.join(PROJECT_ROOT, "data", "raw")
    from src.data.doc_validation import DocumentValidator
    validator = DocumentValidator()
    valid_docs, _, _ = validator.validate_directory(raw_dir)
    extracted_count = len(valid_docs)
    print(f"Airflow Task [extract_text] completed. Extracted text from {extracted_count} documents.")


def task_clean_text():
    from src.data.doc_validation import DocumentValidator
    from src.data.text_processor import TextCleaner
    raw_dir = os.path.join(PROJECT_ROOT, "data", "raw")
    validator = DocumentValidator()
    valid_docs, _, _ = validator.validate_directory(raw_dir)
    cleaner = TextCleaner()
    cleaned_docs = [cleaner.clean_text(d["body"]) for d in valid_docs]
    print(f"Airflow Task [clean_text] completed. Cleaned {len(cleaned_docs)} text bodies.")


def task_chunk_documents():
    from src.data.doc_validation import DocumentValidator
    from src.data.text_processor import load_chunk_params, process_documents
    raw_dir = os.path.join(PROJECT_ROOT, "data", "raw")
    processed_dir = os.path.join(PROJECT_ROOT, "data", "processed")
    params_path = os.path.join(PROJECT_ROOT, "params.yaml")
    
    validator = DocumentValidator()
    valid_docs, _, _ = validator.validate_directory(raw_dir)
    chunk_size, chunk_overlap = load_chunk_params(params_path)
    
    docs, chunks = process_documents(valid_docs, processed_dir=processed_dir, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    print(f"Airflow Task [chunk_documents] completed. Generated {len(chunks)} chunks.")


def task_generate_embeddings():
    from src.vectorstore.embedding_engine import EmbeddingEngine
    chunks_path = os.path.join(PROJECT_ROOT, "data", "processed", "chunks.jsonl")
    chunks = []
    with open(chunks_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                chunks.append(json.loads(line))
                
    engine = EmbeddingEngine()
    texts = [c["text"] for c in chunks]
    embeddings = engine.embed_documents(texts)
    print(f"Airflow Task [generate_embeddings] completed. Embedded {len(embeddings)} chunks (dim: {engine.dimension}).")


def task_update_vector_database():
    from src.vectorstore.chroma_store import ChromaVectorStore
    chunks_path = os.path.join(PROJECT_ROOT, "data", "processed", "chunks.jsonl")
    chunks = []
    with open(chunks_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                chunks.append(json.loads(line))
                
    store = ChromaVectorStore()
    store.reset_collection()
    res = store.add_chunks(chunks)
    print(f"Airflow Task [update_vector_database] completed. Indexed {res['added_count']} chunks in ChromaDB.")


def task_evaluate_retrieval():
    from src.retrieval.semantic_retriever import SemanticRetriever
    from src.evaluation.retrieval_evaluator import RetrievalEvaluator
    dataset_path = os.path.join(PROJECT_ROOT, "data", "evaluation", "rag_questions.jsonl")
    
    evaluator = RetrievalEvaluator(dataset_path=dataset_path)
    retriever = SemanticRetriever()
    metrics = evaluator.evaluate_retriever(retriever, k_values=[1, 3, 5])
    print(f"Airflow Task [evaluate_retrieval] completed. Recall@3: {metrics['recall@3']}, MRR@3: {metrics['mrr@3']}")


def task_evaluate_rag():
    from src.generation.rag_generator import RAGGenerator
    from src.evaluation.rag_evaluator import RAGEvaluator
    dataset_path = os.path.join(PROJECT_ROOT, "data", "evaluation", "rag_questions.jsonl")
    
    generator = RAGGenerator()
    evaluator = RAGEvaluator(dataset_path=dataset_path)
    metrics = evaluator.evaluate_rag_pipeline(generator)
    print(f"Airflow Task [evaluate_rag] completed. Groundedness: {metrics['mean_groundedness_score']}, Relevance: {metrics['mean_answer_relevance']}")


def task_quality_gate():
    from src.generation.rag_generator import RAGGenerator
    from src.evaluation.rag_evaluator import RAGEvaluator
    dataset_path = os.path.join(PROJECT_ROOT, "data", "evaluation", "rag_questions.jsonl")
    
    generator = RAGGenerator()
    evaluator = RAGEvaluator(dataset_path=dataset_path)
    metrics = evaluator.evaluate_rag_pipeline(generator)
    
    # Configurable Quality Gate Thresholds
    MIN_GROUNDEDNESS = 0.80
    MIN_CITATION_RATE = 0.90
    MAX_LATENCY_SEC = 1.00
    
    groundedness = metrics["mean_groundedness_score"]
    citation_rate = metrics["citation_correctness_rate"]
    p95_latency = metrics.get("p95_latency_sec", 0.05)
    
    failures = []
    if groundedness < MIN_GROUNDEDNESS:
        failures.append(f"Groundedness {groundedness:.4f} < threshold {MIN_GROUNDEDNESS}")
    if citation_rate < MIN_CITATION_RATE:
        failures.append(f"Citation Rate {citation_rate:.4f} < threshold {MIN_CITATION_RATE}")
    if p95_latency > MAX_LATENCY_SEC:
        failures.append(f"Latency {p95_latency:.4f}s > threshold {MAX_LATENCY_SEC}s")
        
    if failures:
        raise ValueError(f"Airflow Task [quality_gate] FAILED threshold checks: {failures}")
        
    print(f"Airflow Task [quality_gate] PASSED (Groundedness: {groundedness:.4f}, Citation Rate: {citation_rate:.4f}, Latency: {p95_latency*1000:.2f}ms).")


def task_register_version():
    from src.monitoring.mlflow_tracker import RAGOpsMLflowTracker
    from src.generation.rag_generator import RAGGenerator
    from src.evaluation.rag_evaluator import RAGEvaluator
    
    dataset_path = os.path.join(PROJECT_ROOT, "data", "evaluation", "rag_questions.jsonl")
    generator = RAGGenerator()
    evaluator = RAGEvaluator(dataset_path=dataset_path)
    metrics = evaluator.evaluate_rag_pipeline(generator)
    
    tracker = RAGOpsMLflowTracker()
    run_id = tracker.log_retrieval_run(
        retrieval_method="semantic",
        metrics=metrics,
        params={"airflow_dag": "ragops_enterprise_pipeline"}
    )
    reg_res = tracker.register_champion(run_id=run_id, retrieval_method="semantic", metrics=metrics)
    print(f"Airflow Task [register_version] COMPLETED. Registered Champion Version {reg_res['version']} with alias 'champion'.")


if AIRFLOW_AVAILABLE:
    default_args = {
        "owner": "ragops_team",
        "depends_on_past": False,
        "start_date": datetime(2026, 1, 1),
        "email_on_failure": False,
        "email_on_retry": False,
        "retries": 1,
        "retry_delay": timedelta(minutes=5),
    }

    dag = DAG(
        "ragops_enterprise_pipeline",
        default_args=default_args,
        description="Production-Ready Enterprise Knowledge Assistant Continuous RAGOps Pipeline",
        schedule_interval="@weekly",
        catchup=False,
        tags=["RAGOps", "MLOps", "EnterpriseAssistant"],
    )

    t1 = PythonOperator(task_id="ingest_documents", python_callable=task_ingest_documents, dag=dag)
    t2 = PythonOperator(task_id="validate_documents", python_callable=task_validate_documents, dag=dag)
    t3 = PythonOperator(task_id="extract_text", python_callable=task_extract_text, dag=dag)
    t4 = PythonOperator(task_id="clean_text", python_callable=task_clean_text, dag=dag)
    t5 = PythonOperator(task_id="chunk_documents", python_callable=task_chunk_documents, dag=dag)
    t6 = PythonOperator(task_id="generate_embeddings", python_callable=task_generate_embeddings, dag=dag)
    t7 = PythonOperator(task_id="update_vector_database", python_callable=task_update_vector_database, dag=dag)
    t8 = PythonOperator(task_id="evaluate_retrieval", python_callable=task_evaluate_retrieval, dag=dag)
    t9 = PythonOperator(task_id="evaluate_rag", python_callable=task_evaluate_rag, dag=dag)
    t10 = PythonOperator(task_id="quality_gate", python_callable=task_quality_gate, dag=dag)
    t11 = PythonOperator(task_id="register_version", python_callable=task_register_version, dag=dag)

    t1 >> t2 >> t3 >> t4 >> t5 >> t6 >> t7 >> t8 >> t9 >> t10 >> t11
