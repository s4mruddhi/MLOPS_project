"""
Assignment No. 4: MLOps Workflow Automation Using Apache Airflow
DAG ID: data_pipeline_dag
Course: MLOps
Topic: Build Workflow Automation Using Apache Airflow

Sequence:
Data Extraction -> Data Validation -> Data Processing -> Report Generation -> Notification
"""

import os
import sys
import json
import csv
from datetime import datetime, timedelta

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

try:
    from airflow import DAG
    from airflow.operators.python import PythonOperator
    AIRFLOW_AVAILABLE = True
except ImportError:
    AIRFLOW_AVAILABLE = False


def extract():
    """Task 1: Data Extraction"""
    raw_dir = os.path.join(PROJECT_ROOT, "data", "raw")
    os.makedirs(raw_dir, exist_ok=True)
    extracted_csv_path = os.path.join(raw_dir, "extracted_data.csv")

    # Generate sample dataset for MLOps pipeline
    sample_records = [
        {"id": 1, "feature_age": 25, "feature_income": 50000.0, "target": 1},
        {"id": 2, "feature_age": 30, "feature_income": None, "target": 0},
        {"id": 3, "feature_age": None, "feature_income": 72000.0, "target": 1},
        {"id": 4, "feature_age": 45, "feature_income": 95000.0, "target": 0},
        {"id": 5, "feature_age": 22, "feature_income": 38000.0, "target": 1},
        {"id": 6, "feature_age": 35, "feature_income": 61000.0, "target": 1},
        {"id": 7, "feature_age": 50, "feature_income": 110000.0, "target": 0},
        {"id": 8, "feature_age": 28, "feature_income": None, "target": 1},
        {"id": 9, "feature_age": 40, "feature_income": 84000.0, "target": 0},
        {"id": 10, "feature_age": 32, "feature_income": 67000.0, "target": 1},
    ]

    with open(extracted_csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "feature_age", "feature_income", "target"])
        writer.writeheader()
        writer.writerows(sample_records)

    print(f"Data Extracted: Saved {len(sample_records)} records to {extracted_csv_path}")
    return extracted_csv_path


def validate():
    """Task 2: Data Validation"""
    raw_dir = os.path.join(PROJECT_ROOT, "data", "raw")
    processed_dir = os.path.join(PROJECT_ROOT, "data", "processed")
    os.makedirs(processed_dir, exist_ok=True)

    extracted_csv_path = os.path.join(raw_dir, "extracted_data.csv")
    stats_json_path = os.path.join(processed_dir, "validation_stats.json")

    total_records = 0
    missing_values = 0

    with open(extracted_csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            total_records += 1
            if not row["feature_age"] or not row["feature_income"]:
                missing_values += 1

    stats = {
        "total_records": total_records,
        "missing_values_count": missing_values,
        "valid_records_count": total_records - missing_values,
        "validation_status": "PASSED"
    }

    with open(stats_json_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=4)

    print(f"Data Validated: Total Records = {total_records}, Missing Values = {missing_values}")
    return stats


def process():
    """Task 3: Data Processing"""
    raw_dir = os.path.join(PROJECT_ROOT, "data", "raw")
    processed_dir = os.path.join(PROJECT_ROOT, "data", "processed")
    os.makedirs(processed_dir, exist_ok=True)

    extracted_csv_path = os.path.join(raw_dir, "extracted_data.csv")
    cleaned_csv_path = os.path.join(processed_dir, "cleaned_data.csv")

    cleaned_records = []
    with open(extracted_csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Impute missing values with defaults
            age = float(row["feature_age"]) if row["feature_age"] else 30.0
            income = float(row["feature_income"]) if row["feature_income"] else 60000.0
            cleaned_records.append({
                "id": int(row["id"]),
                "feature_age": age,
                "feature_income": income,
                "target": int(row["target"])
            })

    with open(cleaned_csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "feature_age", "feature_income", "target"])
        writer.writeheader()
        writer.writerows(cleaned_records)

    print(f"Data Processed: Cleaned and stored {len(cleaned_records)} records in {cleaned_csv_path}")
    return cleaned_csv_path


def report():
    """Task 4: Report / Result Generation"""
    processed_dir = os.path.join(PROJECT_ROOT, "data", "processed")
    stats_json_path = os.path.join(processed_dir, "validation_stats.json")
    report_file_path = os.path.join(processed_dir, "summary_report.txt")

    with open(stats_json_path, "r", encoding="utf-8") as f:
        stats = json.load(f)

    report_content = (
        "====================================================\n"
        "           APACHE AIRFLOW WORKFLOW REPORT           \n"
        "====================================================\n"
        f"DAG ID: data_pipeline_dag\n"
        f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        "----------------------------------------------------\n"
        f"Number of Records Processed: {stats['total_records']}\n"
        f"Missing Values Identified: {stats['missing_values_count']}\n"
        f"Valid Records Count: {stats['valid_records_count']}\n"
        f"Processing Completion Status: SUCCESS\n"
        "====================================================\n"
    )

    with open(report_file_path, "w", encoding="utf-8") as f:
        f.write(report_content)

    print(f"Report Generated: Summary saved to {report_file_path}")
    print(report_content)
    return report_file_path


def notify():
    """Task 5: Notification"""
    print("\n" + "*" * 60)
    print("SUCCESS NOTIFICATION:")
    print("Apache Airflow Workflow [data_pipeline_dag] Completed Successfully!")
    print("All tasks: extract -> validate -> process -> report -> notify executed with 0 errors.")
    print("*" * 60 + "\n")


default_args = {
    "owner": "mlops_student",
    "depends_on_past": False,
    "start_date": datetime(2026, 1, 1),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

if AIRFLOW_AVAILABLE:
    with DAG(
        dag_id="data_pipeline_dag",
        default_args=default_args,
        start_date=datetime(2026, 1, 1),
        schedule="@daily",
        catchup=False,
        tags=["MLOps", "Assignment4", "WorkflowAutomation"],
    ) as dag:

        t1 = PythonOperator(task_id="extract", python_callable=extract)
        t2 = PythonOperator(task_id="validate", python_callable=validate)
        t3 = PythonOperator(task_id="process", python_callable=process)
        t4 = PythonOperator(task_id="report", python_callable=report)
        t5 = PythonOperator(task_id="notify", python_callable=notify)

        t1 >> t2 >> t3 >> t4 >> t5
